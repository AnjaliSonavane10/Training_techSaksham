# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 11:51:27 2025

@author: Admin
"""

PLACEHOLDER ="[name]"

with open("names.txt",'r') as names_list:
    names=names_list.readlines()
    
with open("start_Letter.docx") as letter_file:
    letter_content=letter_file.read()
    print(letter_content)
    for name in names:
        stripped_name=name.strip()
        new_content=letter_content.replace(PLACEHOLDER,stripped_name)
        print(new_content)
        with open(f"Completed_letter_(stripped_name).txt",'w') as completed_file:
            completed_file=write(new_content)