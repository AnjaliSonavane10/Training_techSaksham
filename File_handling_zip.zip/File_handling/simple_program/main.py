# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 12:14:17 2025

@author: Admin
"""

file=open("example.txt",'w')
file.write("Hello, this is Anjali Sonavane \n")
file.write("I study in WIT")

file.close()

file=open("example.txt",'r')
content=file.read()

print("File Content are :",content)