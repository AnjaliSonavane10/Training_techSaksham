class Workout:
    def __init__(self, date, exercise_type, duration, calories_burned):
        self.date = date
        self.exercise_type = exercise_type
        self.duration = duration
        self.calories_burned = calories_burned

    def __str__(self):
        return f"{self.date}: {self.exercise_type} for {self.duration} minutes, {self.calories_burned} calories burned"


class User:
    def __init__(self, name, age, weight):
        self.name = name
        self.age = age
        self.weight = weight
        self.workouts = []  # Stores list of Workout objects

    def add_workout(self, workout):
        self.workouts.append(workout)

    def view_workouts(self):
        if not self.workouts:
            print(f"{self.name} has no workouts recorded.")
        else:
            for workout in self.workouts:
                print(workout)

    def save_data(self, filename):
        try:
            with open(filename, "a") as file:  # Append mode to keep old data
                for workout in self.workouts:
                    file.write(f"{workout.date},{workout.exercise_type},{workout.duration},{workout.calories_burned}\n")
            print("Data saved successfully!")
        except Exception as e:
            print(f"Error saving data: {e}")

    def load_data(self, filename):
        try:
            self.workouts = []  # Clear existing workouts before loading
            with open(filename, "r") as file:
                for line in file:
                    date, exercise_type, duration, calories_burned = line.strip().split(",")
                    workout = Workout(date, exercise_type, int(duration), int(calories_burned))
                    self.workouts.append(workout)
            print("Data loaded successfully!")
        except FileNotFoundError:
            print("File not found. Please check the filename.")
        except Exception as e:
            print(f"Error loading data: {e}")
