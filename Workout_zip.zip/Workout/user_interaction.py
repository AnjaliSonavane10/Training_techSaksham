from workout import User, Workout

def add_workout(user):
    date = input("Enter the date (YYYY-MM-DD): ")
    exercise_type = input("Enter the exercise type: ")
    duration = int(input("Enter the duration (minutes): "))
    calories_burned = int(input("Enter calories burned: "))

    workout = Workout(date, exercise_type, duration, calories_burned)
    user.add_workout(workout)
    print("Workout added successfully!")

def view_workouts(user):
    print(f"\n{user.name}'s Workouts:")
    user.view_workouts()

def save_data(user):
    filename = "fitness_data.txt"  # Default filename
    user.save_data(filename)

def load_data(user):
    filename = "fitness_data.txt"  # Default filename
    user.load_data(filename)
