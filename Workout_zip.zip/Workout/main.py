from workout import User
from workout import Workout

def main():
    name = input("Enter your name: ")
    age = int(input("Enter your age: "))
    weight = float(input("Enter your weight (kg): "))

    user = User(name, age, weight)

    while True:
        print("\n1. Add Workout")
        print("2. View Workouts")
        print("3. Save Data")
        print("4. Load Data")
        print("5. Exit")
        
        choice = input("Choose an option: ")

        if choice == "1":
            date = input("Enter the date (YYYY-MM-DD): ")
            exercise_type = input("Enter the exercise type: ")
            duration = int(input("Enter the duration (minutes): "))
            calories_burned = int(input("Enter calories burned: "))

            workout = Workout(date, exercise_type, duration, calories_burned)
            user.add_workout(workout)
            print("Workout added successfully!")

        elif choice == "2":
            user.view_workouts()

        elif choice == "3":
            user.save_data("fitness_data.txt")

        elif choice == "4":
            user.load_data("fitness_data.txt")

        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
