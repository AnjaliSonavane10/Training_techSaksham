# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 10:56:53 2025

@author: Admin
"""

def add(num1, num2, num3):
    return num1 + num2 + num3

def subtract(num1, num2, num3):
    return num1 - num2 - num3

def multiply(num1, num2, num3):
    return num1 * num2 * num3

def divide(num1, num2, num3):
    if num2 == 0 and num3 == 0:
        return "Cannot divide by zero"
    return num1 / num2 / num3

def calculator():
    num1 = int(input("Enter first number: "))
    num2 = int(input("Enter second number: "))
    num3 = int(input("Enter Third number: "))

    while True:
        print("\nChoose an operation:")
        print("1: Addition")
        print("2: Subtraction")
        print("3: Multiplication")
        print("4: Division")
        print("5: Exit")

        choice = input("Enter your choice (1-5): ")

        if choice == "1":
            print("Result:", add(num1, num2, num3))
        elif choice == "2":
            print("Result:", subtract(num1, num2, num3))
        elif choice == "3":
            print("Result:", multiply(num1, num2, num3))
        elif choice == "4":
            print("Result:", divide(num1, num2, num3))
        elif choice == "5":
            print("Exiting...")
            break
        else:
            print("Invalid choice!! Try again.")