# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 10:57:15 2025

@author: Admin
"""

import my_module

my_module.calculator()